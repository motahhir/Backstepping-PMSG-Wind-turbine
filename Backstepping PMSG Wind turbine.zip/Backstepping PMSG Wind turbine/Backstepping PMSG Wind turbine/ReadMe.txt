This folder contains :

- Wind Turbine Model

- Backstepping Control for Wind turbine based on the PMSG Generator



Please cite this work as: 

1.	Salime, H.; Bossoufi, B.; El Mourabit, Y.; Motahhir, S. Robust Nonlinear Adaptive Control for Power Quality Enhancement of PMSG Wind Turbine: Experimental Control Validation. Sustainability2023, 15, 939. https://doi.org/10.3390/su15020939.

2.	F. Echiheb, Y. Ihedrane, B. Bossoufi, M.Bouderbala, S.Motahhir, M. Masud, S. Aljahdali, M. El Ghamrasni. Robust Sliding-Backstepping mode Control of a wind system based on the DFIG Generator. Scientific Reports, Vol.12, pp 11782, July 2022.

3.	Majout, B.; El Alami, H.; Salime, H.; Zine Laabidine, N.; El Mourabit, Y.; Motahhir, S.; Bouderbala, M.; Karim, M.; Bossoufi, B. A Review on Popular Control Applications in Wind Energy Conversion System Based on Permanent Magnet Generator PMSG. Energies 2022, 15, 6238. https://doi.org/10.3390/en15176238 

4.	B.BOSSOUFI, M.KARIM, M.TAOUSSI, H. ALAMI AROUSSI, M. BOUDERBALA, O. DEBLECKER, S. MOTAHHIR, A. NAYYAR,M.MASUD “Rooted Tree Optimization for Backstepping Power Control of DFIG Wind Turbine: dSPACE Implementation” IEEE Access, Vol. 9, No 1. p. 26512 – 26522, February 2021

5.	B.BOSSOUFI, M.TAOUSSI, H. ALAMI AROUSSI, M. BOUDERBALA, S.MOTAHHIR, M.B.CAMARA “DSPACE-Based Implementation for Observer Backstepping Power Control of DFIG Wind Turbine” IET Electric Power Applications, Vol. 14, No 12. p. 2395 – 2403, December 2020. 






For more papers and works please visit : https://sites.google.com/usmba.ac.ma/motahhir/home









