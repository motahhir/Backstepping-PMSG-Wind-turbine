%%%%%%%machine synchrone
Rs=6.25e-3 ;
Ld=4.229e-3 ;
Lq=4.229e-3;
p=75  ; 
flux=11.1464;

%%%%%% filtre
Lf=10e-3;
Rf=0;

%%%%%% bus continu
Cbus=0.06;

%%%%% temps ech
Ts=10e-6;
eps=0.707;

%%%donnes terbune
%R= 58 ;         
%rho=1.22;
%J=10e4;
%F=0;
%cpmax=0.5439;
%hopt=6.899;
R= 55 ;            
rho=1.22;
J=10000;
F=0;
cpmax=0.35;
lamopt=7.07;
K=1;

% regulation du courant idm et iqm 

%%courant idm
wnidm=2*pi/(100e-3);
Iid=Ld*(wnidm^2);
Pid=(2*eps*Ld*wnidm)-Rs;

%%courant iqm
%wniqm=2*pi/(40e-3);
wniqm=2*pi/(100e-3);
Iiq=Lq*(wniqm^2);
Piq=(2*eps*Lq*wniqm)-Rs;

% regulation du courant reseau idr et iqr

%%regulateur courant Idr
Widr=2*pi/40e-03;
Iidr=Lf*((Widr)^2);
Pidr=(2*eps*Lf*Widr)-Rf;

%%regulateur courant Iqr
Wiqr=2*pi/40e-03;
Iiqr=Lf*((Wiqr)^2);
Piqr=(2*eps*Lf*Wiqr)-Rf;

%%regulateur bus continu
Wudc=2*pi/200e-03;
IVdc=Cbus*((Wudc)^2);
PVdc=Cbus*2*eps*Wudc;

% regulateur de vitesse 
wnvitesse=2*pi/0.09;
%Iwm=J*(wnvitesse^2);
%Pwm=2*eps*J*wnvitesse-F;
kpv=2*eps*wnvitesse*J;
kiv=wnvitesse*wnvitesse*J;

%%%%%PLL0.038648
wpll=2*pi/0.07;
kpPLL=2*eps*wpll;
DiPLL=2*eps/(wpll);
kiPLL=kpPLL/DiPLL;

%%%%%%regulateur Beta-Puissance
PPbeta=-5.6e-7;
top=0.015;
IPbeta=PPbeta/top;

%%%%%%regulateur puissance reactive
Vd1=-1260;
beta1=-(3/2)*Vd1;
tr1=100e-3;
IQr=0.02;
KQr=tr1*IQr-(1/beta1);

